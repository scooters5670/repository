import urllib, urllib2, sys, re, xbmcplugin, xbmcgui, xbmcaddon, datetime, os, json, base64, plugintools, calendar, time, hashlib
import xml.etree.ElementTree as ElementTree

reload(sys)
sys.setdefaultencoding('utf8')

SKIN_VIEW_FOR_MOVIES = "515"
addonDir = plugintools.get_runtime_path()

global kontroll

background = "background.png"
defaultlogo = "defaultlogo.png"
hometheater = "hometheater.jpg"
noposter = "noposter.jpg"
theater = "theater.jpg"
addonxml = "addon.xml"
addonpy = "default.py"
icon = "icon.png"
fanart = "fanart.png"
message = "UNAUTHORIZED EDIT OF ADDON!"  # BINGO!!!!


# Entry point
def main():
    global pnimi
    global televisioonilink
    global filmilink
    global andmelink
    global uuenduslink
    global server
    global LOAD_LIVE
    global parentalLock
    global version
    global tvlink
    global tvkategoorialink
    global arhiivilink
    global playlist
    global tvshows

    version = int("3")

    # if not plugintools.get_setting("kasutajanimi"):
    #     plugintools.open_settings_dialog()

    # NOTE: These values can be hardcoded if the settings menu is hidden
    username = plugintools.get_setting("kasutajanimi")
    password = plugintools.get_setting("salasona")
    server = plugintools.get_setting("lehekylg")
    port = plugintools.get_setting("pordinumber")
    parentalLock = plugintools.get_setting("vanemalukk")
    playlist = plugintools.get_setting("striimiv2ljund")

    tvshows = "TV SHOWS"
    pnimi = "JesusBoxTV"
    
    LOAD_LIVE = os.path.join(plugintools.get_runtime_path(), "resources", "art")
    plugintools.log(pnimi + "Starting up")

    """ VERSION 1 CODE
    ######################################################
    televisioonilink = get_live("%s:%s/enigma2.php?username=%s&password=%s&type=get_live_categories")%(server,port,username,password)
    filmilink = vod_channels("%s:%s/enigma2.php?username=%s&password=%s&type=get_vod_categories")%(server,port,username,password)
    andmelink = vod_channels("%s:%s/panel_api.php?username=%s&password=%s")%(server,port,username,password)
    uuenduslink = get_live("https://www.dropbox.com/s/7em24wd1pddidqo/version.txt?dl=1")
    ######################################################
    """

    televisioonilink = "%s:%s/enigma2.php?username=%s&password=%s&type=get_live_categories" % (server, port, username, password)
    filmilink = "%s:%s/enigma2.php?username=%s&password=%s&type=get_vod_categories" % (server, port, username, password)
    andmelink = "%s:%s/panel_api.php?username=%s&password=%s" % (server, port, username, password)
    uuenduslink = "https://www.dropbox.com/s/powbxk0d0bx8179/kingVersion.txt?dl=1"
    tvlink = "%s:%s/enigma2.php?username=%s&password=%s&type=get_vod_categories" % (server, port, username, password)
    arhiivilink = "%s:%s/streaming/timeshift.php?username=%s&password=%s" % (server, port, username, password)

    params = plugintools.get_params()

    if params.get("action") is None:
        peamenyy(params)
    else :
        action = params.get("action")
        exec action + "(params)"

    plugintools.close_item_list()


def peamenyy(params):
    plugintools.log(pnimi + "Main Menu " + repr(params))

    if not server:
        plugintools.open_settings_dialog()

    channels = kontroll()
    timestamp = (time.strftime("%d/%m/%Y"))

    if channels == 1:
        plugintools.log(pnimi + "Login Success")

        plugintools.add_item(
            action = "executeainfo",
            title = "My Account",
            thumbnail = os.path.join(LOAD_LIVE, "logo.png"),
            fanart = os.path.join(LOAD_LIVE, "background.png"), 
            folder = True
        )
        plugintools.add_item(
            action = "execute_live_tv",
            title = "Live TV",
            thumbnail = os.path.join(LOAD_LIVE, "logo.png"),
            fanart = os.path.join(LOAD_LIVE, "background.png"), 
            folder = True
        )
        # plugintools.add_item(
        #     action = "execute_vod",
        #     title = "Video On Demand",
        #     thumbnail = os.path.join(LOAD_LIVE, "logo.png"),
        #     fanart = os.path.join(LOAD_LIVE, "background.png"), 
        #     folder = True
        # )
        plugintools.add_item(
            action = "execute_tv",
            title = "TV Shows",
            thumbnail = os.path.join(LOAD_LIVE, "logo.png"),
            fanart = os.path.join(LOAD_LIVE, "background.png"), 
            folder = True
        )
        # plugintools.add_item(
        #     action = "execute_tv_catchup",
        #     title = "TV Catch Up",
        #     thumbnail = os.path.join(LOAD_LIVE, "logo.png"),
        #     fanart = os.path.join(LOAD_LIVE, "background.png"), 
        #     folder = True
        # )
        plugintools.add_item(
            action = "execute_settings",
            title = "Settings",
            thumbnail = os.path.join(LOAD_LIVE, "logo.png"),
            fanart = os.path.join(LOAD_LIVE, "background.png"), 
            folder = False
        )
        plugintools.set_view(plugintools.LIST)
    else :
        plugintools.log(pnimi + "Login failed")
        plugintools.message("Login failed",
            "Possible reasons: Wrong host,port,username or pass.          Please reconfigure %s plugin with correct details!" % (pnimi))
        plugintools.open_settings_dialog()
        main()

    if plugintools.get_setting("improve") == "true":
        tseaded = xbmc.translatePath("special://userdata/advancedsettings.xml")

        if not os.path.exists(tseaded):
            file = open(os.path.join(plugintools.get_runtime_path(), "resources", "advancedsettings.xml"))
            data = file.read()
            file.close()
            file = open(tseaded, "w")
            file.write(data)
            file.close()
            plugintools.message(pnimi, "New advanced streaming settings added.")


def execute_settings(params):
    plugintools.log(pnimi + "Settings menu " + repr(params))
    plugintools.open_settings_dialog()


def execute_live_tv(params):
    plugintools.log(pnimi + "Live Menu " + repr(params))
    request = urllib2.Request(televisioonilink, headers = {
        "Accept": "application/xml"
    })
    u = urllib2.urlopen(request)
    tree = ElementTree.parse(u)
    root_elem = tree.getroot()

    for channel in tree.findall("channel"):
        kanalinimi = channel.find("title").text
        kanalinimi = base64.b64decode(kanalinimi)
        kategoorialink = channel.find("playlist_url").text
        plugintools.add_item(
            action = "stream_video",
            title = kanalinimi,
            url = kategoorialink,
            thumbnail = os.path.join(LOAD_LIVE, "logo.png"),
            fanart = os.path.join(LOAD_LIVE, "theater.jpg"), 
            folder = True
        )
    plugintools.set_view(plugintools.LIST)


def execute_vod(params):
    plugintools.log(pnimi + "VOD Menu " + repr(params))
    request = urllib2.Request(filmilink, headers = {
        "Accept": "application/xml"
    })
    u = urllib2.urlopen(request)
    tree = ElementTree.parse(u)
    root_elem = tree.getroot()

    for channel in tree.findall("channel"):
        filminimi = channel.find("title").text
        if filminimi == "TV SHOWS":
            continue
        if filminimi == "All":
            continue
        filminimi = base64.b64decode(filminimi)
        kategoorialink = channel.find("playlist_url").text
        plugintools.add_item(
            action = "get_myaccount",
            title = filminimi,
            url = kategoorialink,
            thumbnail = os.path.join(LOAD_LIVE, "logo.png"),
            fanart = os.path.join(LOAD_LIVE, "theater.jpg"), 
            folder = True
        )
    plugintools.set_view(plugintools.LIST)


def stream_video(params):
    plugintools.log(pnimi + "Live Channels Menu " + repr(params))

    if parentalLock == "true":
        pealkiri = params.get("title")
        parental_lock(pealkiri)

    url = params.get("url")
    request = urllib2.Request(url, headers = {
        "Accept": "application/xml"
    })

    u = urllib2.urlopen(request)
    tree = ElementTree.parse(u)
    root_elem = tree.getroot()

    for channel in tree.findall("channel"):
        kanalinimi = channel.find("title").text
        kanalinimi = base64.b64decode(kanalinimi)
        kanalinimi = kanalinimi.partition("[")
        striimilink = channel.find("stream_url").text
        pilt = channel.find("desc_image").text
        kava = kanalinimi[1] + kanalinimi[2]
        kava = kava.partition("]")
        kava = kava[2]
        kava = kava.partition("         ")
        kava = kava[2]
        shou = "[COLOR white]%s [/COLOR]" % (kanalinimi[0]) + kava
        kirjeldus = channel.find("description").text

        if kirjeldus:
            kirjeldus = base64.b64decode(kirjeldus)
            nyyd = kirjeldus.partition("(")
            nyyd = "NOW: " + nyyd[0]
            jargmine = kirjeldus.partition(")\n")
            jargmine = jargmine[2].partition("(")
            jargmine = "NOW: " + jargmine[0]
            kokku = nyyd + jargmine
        else :
            kokku = ""

        if playlist == "true":
            striimilink = striimilink.replace(".ts", ".m3u8")

        if pilt:  # If thumbnail reference is not None
            pilt = pilt.strip()
            plugintools.add_item(
                action = "run_cronjob",
                title = shou,
                url = striimilink,
                thumbnail = pilt,
                plot = kokku,
                fanart = os.path.join(LOAD_LIVE, "hometheater.jpg"),
                extra = "",
                isPlayable = True,
                folder = False
            )
        else :
            plugintools.add_item(
                action = "run_cronjob",
                title = shou,
                url = striimilink,
                thumbnail = os.path.join(LOAD_LIVE, "defaultlogo.png"),
                plot = kokku,
                fanart = os.path.join(LOAD_LIVE, "hometheater.jpg"),
                extra = "",
                isPlayable = True,
                folder = False)

    plugintools.set_view(plugintools.EPISODES)
    xbmc.executebuiltin("Container.SetViewMode(503)")


def get_myaccount(params):
    plugintools.log(pnimi + "VOD channels menu " + repr(params))

    if parentalLock == "true":
        pealkiri = params.get("title")
        parental_lock(pealkiri)

    purl = params.get("url")
    request = urllib2.Request(purl, headers = {
        "Accept": "application/xml"
    })
    u = urllib2.urlopen(request)
    tree = ElementTree.parse(u)
    root_elem = tree.getroot()

    for channel in tree.findall("channel"):
        pealkiri = channel.find("title").text
        pealkiri = base64.b64decode(pealkiri)
        pealkiri = pealkiri.encode("utf-8")
        striimilink = channel.find("stream_url").text
        pilt = channel.find("desc_image").text
        kirjeldus = channel.find("description").text

        if kirjeldus:
            kirjeldus = base64.b64decode(kirjeldus)

        if pilt:  # If thumbnail reference is not None
            plugintools.add_item(
                action = "restart_service",
                title = pealkiri,
                url = striimilink,
                thumbnail = pilt,
                plot = kirjeldus,
                fanart = os.path.join(LOAD_LIVE, "theater.jpg"),
                extra = "",
                isPlayable = True,
                folder = False
            )
        else :
            plugintools.add_item(
                action = "restart_service",
                title = pealkiri,
                url = striimilink,
                thumbnail = os.path.join(LOAD_LIVE, "noposter.jpg"),
                plot = kirjeldus, fanart = "",
                extra = "",
                isPlayable = True,
                folder = False
            )

    plugintools.set_view(plugintools.MOVIES)
    xbmc.executebuiltin('Container.SetViewMode(515)')


def execute_tv(params):
    plugintools.log(pnimi + "TV Shows " + repr(params))
    request = urllib2.Request(tvlink, headers = {
        "Accept": "application/xml"
    })
    u = urllib2.urlopen(request)
    tree = ElementTree.parse(u)
    root_elem = tree.getroot()
    found_stream = 0

    for channel in tree.findall("channel"):
        filminimi = channel.find("title").text

        # Is this really comparing to a base encoded string??
        if filminimi == "VFYgU0hPV1M=":  #NOTE: I didn't change this
            found_stream = 1
            global tvkategoorialink
            tvkategoorialink = channel.find("playlist_url").text
            search_category(params)

    if found_stream == 0:
        plugintools.message(pnimi, "There   are no  TV  series  available")


def search_category(params):
    plugintools.log(pnimi + "Get    tv  show    cats" + repr(params))
    global tvkategoorialink

    request = urllib2.Request(tvkategoorialink, headers = {
        "Accept": "application/xml"
    })
    u = urllib2.urlopen(request)
    tree = ElementTree.parse(u)
    root_elem = tree.getroot()

    for channel in tree.findall("channel"):
        filminimi = channel.find("title").text
        filminimi = base64.b64decode(filminimi)
        kategoorialink = channel.find("playlist_url").text
        plugintools.add_item(
            action = "get_myaccount",
            title = filminimi,
            url = kategoorialink,
            thumbnail = os.path.join(LOAD_LIVE, "logo.png"),
            fanart = os.path.join(LOAD_LIVE, "series.jpg"),
            folder = True
        )

    plugintools.set_view(plugintools.LIST)


def run_cronjob(params):
    plugintools.log(pnimi + "PLAY_LIVE " + repr(params))

    if parentalLock == "true":
        pealkiri = params.get("title")
        parental_lock(pealkiri)

    tmpUrl = params.get("url")
    # tmpUrl = "http://iptv.leeztv.com/relocate.php?loc=" + tmpUrl
    plugintools.log(tmpUrl)
    plugintools.play_resolved_url(tmpUrl)


def restart_service(params):
    plugintools.log(pnimi + "PLAY VOD " + repr(params))

    if parentalLock == "true":
        pealkiri = params.get("title")
        parental_lock(pealkiri)

    tmpUrl = params.get("url")
    plugintools.play_resolved_url(tmpUrl)


def exit():
    plugintools.log("Your kodi version is outdated!")
    sys.exit()


def grab_epg():
    try:
        tmpReq = urllib2.Request(andmelink)
        # NOTE: This seems interesting/important ;)
        tmpReq.add_header("User-Agent", "Kodi plugin by MikkM")
        tmpResponse = urllib2.urlopen(tmpReq)
        tmpData = tmpResponse.read()
        # NOTE: This is the call throwing the ValueError when login info is missing
        tmpJson = json.loads(tmpData.decode('utf8'))
        tmpResponse.close()

        if tmpJson:
            plugintools.log(pnimi + "jdata loaded ")
            return tmpJson

    except ValueError:
        plugintools.open_settings_dialog()
        sys.exit()



def kontroll():
    randomstring = grab_epg()
    kasutajainfo = randomstring["user_info"]
    kontroll = kasutajainfo["auth"]
    return kontroll


def executeainfo(params):
    plugintools.log(pnimi + "My account Menu " + repr(params))
    accInfo = grab_epg()
    usrInfo = accInfo["user_info"]
    usrStatus = usrInfo["status"]
    usrExpires = usrInfo["exp_date"]

    if usrExpires:
        usrExpires = datetime.datetime.fromtimestamp(int(usrExpires)).strftime('%H:%M   %d.%m.%Y')
    else :
        usrExpires = "Never"

    usrTrial = usrInfo["is_trial"]

    if usrTrial == "0":
        usrTrial = "No"
    else :
        usrTrial = "Yes"

    usrMaxConn = usrInfo["max_connections"]
    usrName = usrInfo["username"]
    plugintools.add_item(
        action = "",
        title = "[COLOR = white]User: [/COLOR]" + usrName,
        thumbnail = os.path.join(LOAD_LIVE, "logo.png"),
        fanart = os.path.join(LOAD_LIVE, "background.png"),
        folder = False
    )
    plugintools.add_item(
        action = "",
        title = "[COLOR = white]Status: [/COLOR]" + usrStatus,
        thumbnail = os.path.join(LOAD_LIVE, "logo.png"),
        fanart = os.path.join(LOAD_LIVE, "background.png"),
        folder = False
    )
    plugintools.add_item(
        action = "",
        title = "[COLOR = white]Expires: [/COLOR]" + usrExpires,
        thumbnail = os.path.join(LOAD_LIVE, "logo.png"),
        fanart = os.path.join(LOAD_LIVE, "background.png"),
        folder = False
    )
    plugintools.add_item(
        action = "",
        title = "[COLOR = white]Trial account: [/COLOR]" + usrTrial,
        thumbnail = os.path.join(LOAD_LIVE, "logo.png"),
        fanart = os.path.join(LOAD_LIVE, "background.png"),
        folder = False
    )
    plugintools.add_item(
        action = "",
        title = "[COLOR = white]Max connections: [/COLOR]" + usrMaxConn,
        thumbnail = os.path.join(LOAD_LIVE, "logo.png"),
        fanart = os.path.join(LOAD_LIVE, "background.png"),
        folder = False
    )
    plugintools.set_view(plugintools.LIST)


def parental_lock(name):
    plugintools.log(pnimi + "Parental lock ")
    filter_list = 'XXX', 'Adult', 'Adults', 'ADULT', 'ADULTS', 'adult', 'adults', 'Porn', 'PORN', 'porn', 'Porn', 'xxx'

    if any(s in name for s in filter_list):
        xbmc.executebuiltin((u'XBMC.Notification("Parental Lock",  "Channels   may contain adult   content",   2000)'))
        lock_code = plugintools.keyboard_input(default_text = "", title = "Parental lock")

        if lock_code == plugintools.get_setting("vanemakood"):
            return
        else :
            exit()

    else :
        name = ""


def execute_tv_catchup(params): #tv archive cat
    tmpData = urllib2.urlopen(andmelink)
    tmpJson = json.load(tmpData)
    channel_list = tmpJson['available_channels']

    for channel in channel_list.values():
        archive = channel['tv_archive']

        if (archive == 1):
            title = channel['name']
            streamUrl = channel['stream_id']
            plugintools.add_item(
                action = "get_archive_list",
                title = title,
                url = streamUrl,
                thumbnail = os.path.join(LOAD_LIVE, "logo.png"),
                fanart = os.path.join(LOAD_LIVE, "tvc.jpg"),
                isPlayable = False,
                folder = True)


def play_stream(params):
    plugintools.log(pnimi + "   TESTING" + repr(params))
    tmpUrl = params.get("url")
    tmpUrl = tmpUrl.split("#")
    streamUrl = tmpUrl[0]
    resumeTime = tmpUrl[1]
    tmpUrl = arhiivilink + "&stream=" + streamUrl + "&duration=120" + "&start=" + resumeTime
    plugintools.log("Lopplink   " + tmpUrl)
    plugintools.play_resolved_url(tmpUrl)


def get_archive_list(params): #tv archive list
    streamUrl = params.get("url")
    url = andmelink + "&action=get_epg&stream_id=" + streamUrl
    tmpData = urllib2.urlopen(url)
    data = json.load(tmpData)
    searchDelta = datetime.datetime.utcnow() - datetime.timedelta(days = 3)
    unixDelta = calendar.timegm(searchDelta.timetuple())
    unixDelta = int(unixDelta)
    timeNow = time.time()
    timeNow = int(timeNow)

    for video in data:
        title = video['title']
        title = base64.b64decode(title)
        vidTime = int(video['start'])

        if (vidTime > unixDelta and vidTime < timeNow):
            dtObj_1 = datetime.datetime.fromtimestamp(int(vidTime)).strftime('%d.%m %H:%M')
            dtObj_2 = datetime.datetime.fromtimestamp(int(vidTime)).strftime('%Y-%m-%d:%H-%M')
            title = dtObj_2 + "  " + title
            tmpUrl = streamUrl + "#" + dtObj_2
            plugintools.add_item(
                action = "play_stream",
                title = title,
                url = tmpUrl,
                thumbnail = os.path.join(LOAD_LIVE, "logo.png"),
                fanart = os.path.join(LOAD_LIVE, "tvc.jpg"),
                isPlayable = True,
                folder = False
            )


main()