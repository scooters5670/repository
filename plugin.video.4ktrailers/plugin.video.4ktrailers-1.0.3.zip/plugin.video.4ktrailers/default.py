# -*- coding: utf-8 -*-
#------------------------------------------------------------
# Youtube Channel
# (c) 2017 - 4K Trailers
# Based on code from youtube addon
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.4ktrailers'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')


channellist=[
        ("Kids New Movie Trailers 4K", "channel/UCq8E0inhGNQaDu-a4KLJJZQ", 'https://yt3.ggpht.com/-fH2xR6xgf4Y/AAAAAAAAAAI/AAAAAAAAAAA/rP1yJ9zl33c/s100-c-k-no-mo-rj-c0xffffff/photo.jpg'),
        ("JoBlo New Movie Clips 4K & HD", "channel/UC6LDwTYRfjQwkakw5R95OyA", 'https://yt3.ggpht.com/-JuWC1XsqHcQ/AAAAAAAAAAI/AAAAAAAAAAA/PO4hZZDLUk8/s88-c-k-no-mo-rj-c0xffffff/photo.jpg'),
        ("Hot New Trailers HD", "channel/UCi8e0iOVk1fEOogdfu4YgfA", 'https://yt3.ggpht.com/-IT-HVCNwnkU/AAAAAAAAAAI/AAAAAAAAAAA/UpKKb5P-gkk/s100-c-k-no-mo-rj-c0xffffff/photo.jpg'),
        ("Coolest Clips 4K UHD", "channel/UCU8PFISdwVu66Zg4cyVbzsw", 'http://jesusboxmediawizard.com/Jesusboxwizard/Images/4KTrailer.png'),
        ("Fresh New Movie Trailers UHD", "channel/UCzNWVDZQ55bjq8uILZ7_wyQ", 'https://yt3.ggpht.com/-VmnWFt29mbM/AAAAAAAAAAI/AAAAAAAAAAA/2EWzCkZnbe4/s100-c-k-no-mo-rj-c0xffffff/photo.jpg'),
        ("Action Movieclips HD", "channel/UCMPpJM24OLE-PmwedcGibWw", 'https://yt3.ggpht.com/-A2HrgdZBkc8/AAAAAAAAAAI/AAAAAAAAAAA/WuZhdiHsbOM/s100-c-k-no-mo-rj-c0xffffff/photo.jpg'),
        ("KinoCheck UHD", "channel/UCLRlryMfL8ffxzrtqv0_k_w", 'https://yt3.ggpht.com/-P_ZY4MNGn90/AAAAAAAAAAI/AAAAAAAAAAA/7ZHNL4Qrhi8/s100-c-k-no-mo-rj-c0xffffff/photo.jpg'),
        ("THG Fansite HD", "channel/UC5kbrYM6LZHkcXm5jaRNgnA", 'https://yt3.ggpht.com/-DEIGXfzWDBU/AAAAAAAAAAI/AAAAAAAAAAA/wAGlISYFCuY/s100-c-k-no-mo-rj-c0xffffff/photo.jpg'),
        ("Family PG Movies HD", "channel/UCx554p1Bu_Mp1q0H_bEtZ1Q", 'https://yt3.ggpht.com/-nyif4-L-C2U/AAAAAAAAAAI/AAAAAAAAAAA/yzcZQKPs29A/s100-c-k-no-mo-rj-c0xffffff/photo.jpg'),
        ("Disney Movie Trailers HD", "channel/UCuaFvcY4MhZY3U43mMt1dYQ", 'https://yt3.ggpht.com/-tFEqAImMiYY/AAAAAAAAAAI/AAAAAAAAAAA/bBNCkTJlFeQ/s100-c-k-no-mo-rj-c0xffffff/photo.jpg'),
        			
]



# Entry point
def run():
    plugintools.log("4ktrailers.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("4ktrailers.main_list "+repr(params))

for name, id, icon in channellist:
	plugintools.add_item(title=name,url="plugin://plugin.video.youtube/"+id+"/",thumbnail=icon,folder=True )



run()